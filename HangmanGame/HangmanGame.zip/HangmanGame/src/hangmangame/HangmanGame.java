
package hangmangame;

public class HangmanGame {

    HangmanFrame frame;
	public HangmanGame(){
		 frame = new HangmanFrame();
		
	}
    public static void main(String[] args) {
       new HangmanGame();
    }
    
}
